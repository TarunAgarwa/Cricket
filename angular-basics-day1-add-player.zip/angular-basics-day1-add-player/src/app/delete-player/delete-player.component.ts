import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';
import { Player } from '../player';

@Component({
  selector: 'app-delete-player',
  templateUrl: './delete-player.component.html',
  styleUrls: ['./delete-player.component.scss']
})
export class DeletePlayerComponent implements OnInit {
  player: Player[] = [];
  id: number;
  
  constructor(private service: CricketService) { }

  ngOnInit() {
    this.getplay();
  }
  getplay() {
    this.service.getPlayers().subscribe((res: any) => {
      console.log("hello");
      this.player = res.data;
    },
      err => {
        console.log(err);
        alert('player creation failed try again...');
      });
  }
  deleteplayer(id1) {
    this.id = id1;
    this.service.deletePlayer(this.id).subscribe((res: any) => {
      console.log("hello")
      this.player = res.data;
      alert("player deleted successfully")
    },
      err => {
        alert('player creation failed try again...');
      });

  }
}


