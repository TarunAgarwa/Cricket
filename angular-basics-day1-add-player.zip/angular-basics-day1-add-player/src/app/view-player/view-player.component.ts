import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { CricketService } from '../cricket.service';
@Component({
  selector: 'app-view-player',
  templateUrl: './view-player.component.html',
  styleUrls: ['./view-player.component.scss']
})
export class ViewPlayerComponent implements OnInit {

  player:Player[]=[];
  constructor(private service: CricketService) { }

  ngOnInit() {
    this.getplay();
  }
getplay(){
  this.service.getPlayers().subscribe((res:any)=>{
    console.log("hello");
    this.player=res.data;
  },
  err => {
    console.log(err);
    alert('player creation failed try again...');
  })
}
}
